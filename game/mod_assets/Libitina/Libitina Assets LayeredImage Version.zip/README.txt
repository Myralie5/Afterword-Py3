If you are using Mood Pose Tool (MPT), copy the definition file from inside
the "MPT Def File" folder to your game folder or somewhere in your mod.

If you are using ExPoser, copy the definition file from inside the "ExP Def File"
folder to your game folder or somewhere in your mod.

If you are not using ExPoser Previewer, do not add "libitina_syntax_def.rpy" to your
game folder.